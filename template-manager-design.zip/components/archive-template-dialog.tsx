"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import type { Template } from "@/app/page"

interface ArchiveTemplateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  template: Template | null
  onConfirm: () => void
}

export function ArchiveTemplateDialog({ open, onOpenChange, template, onConfirm }: ArchiveTemplateDialogProps) {
  if (!template) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Archive Template</DialogTitle>
          <DialogDescription>
            Are you sure you want to archive this template? Archived templates can be restored later.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <div className="p-3 bg-slate-50 rounded-md border border-slate-200">
            <div className="text-sm font-medium text-slate-900">{template.name}</div>
            <div className="text-xs text-slate-500 mt-1">Version {template.version}</div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={onConfirm}>Archive</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
