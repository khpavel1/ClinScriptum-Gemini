"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import type { TreeNode } from "@/app/page"

interface AddSectionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (section: Omit<TreeNode, "id" | "mappings">) => void
  parentNumber?: string
}

export function AddSectionDialog({ open, onOpenChange, onSave, parentNumber }: AddSectionDialogProps) {
  const [number, setNumber] = useState("")
  const [title, setTitle] = useState("")
  const [type, setType] = useState<"text" | "table" | "mixed">("text")
  const [isMandatory, setIsMandatory] = useState(true)
  const [description, setDescription] = useState("")

  const handleSave = () => {
    if (number.trim() && title.trim()) {
      onSave({
        number,
        title,
        type,
        isMandatory,
        description,
        children: [],
      })
      // Reset form
      setNumber("")
      setTitle("")
      setType("text")
      setIsMandatory(true)
      setDescription("")
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Section</DialogTitle>
          <DialogDescription>
            {parentNumber ? `Add a subsection to ${parentNumber}` : "Add a new section to the template"}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="number">Section Number</Label>
            <Input
              id="number"
              placeholder={parentNumber ? `${parentNumber}.1` : "e.g., 1"}
              value={number}
              onChange={(e) => setNumber(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="title">Section Title</Label>
            <Input
              id="title"
              placeholder="e.g., Introduction"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="type">Content Type</Label>
            <Select value={type} onValueChange={(value: any) => setType(value)}>
              <SelectTrigger id="type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="table">Table</SelectItem>
                <SelectItem value="mixed">Mixed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Brief description of section content..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="mandatory" checked={isMandatory} onCheckedChange={(checked) => setIsMandatory(!!checked)} />
            <Label htmlFor="mandatory" className="text-sm font-normal cursor-pointer">
              This section is mandatory
            </Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!number.trim() || !title.trim()}>
            Add Section
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
