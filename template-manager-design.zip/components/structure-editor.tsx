"use client"

import { Maximize2, Minimize2, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { TreeView } from "@/components/tree-view"
import type { Template, TreeNode } from "@/app/page"

interface StructureEditorProps {
  template: Template | null
  treeData: TreeNode[]
  selectedNode: TreeNode | null
  onSelectNode: (node: TreeNode) => void
  onAddSection: () => void
  onEditSection: (node: TreeNode) => void
  onAddChildSection: (parentNode: TreeNode) => void
  onMoveUp: (node: TreeNode) => void
  onMoveDown: (node: TreeNode) => void
  onDeleteSection: (node: TreeNode) => void
  onIndent: (node: TreeNode) => void
  onOutdent: (node: TreeNode) => void
  onExpandAll: () => void
  onCollapseAll: () => void
  expandedIds: Set<string> // Added expandedIds prop
  onToggleExpand: (id: string) => void // Added toggle callback prop
}

export function StructureEditor({
  template,
  treeData,
  selectedNode,
  onSelectNode,
  onAddSection,
  onEditSection,
  onAddChildSection,
  onMoveUp,
  onMoveDown,
  onDeleteSection,
  onIndent,
  onOutdent,
  onExpandAll,
  onCollapseAll,
  expandedIds, // Receive expandedIds
  onToggleExpand, // Receive toggle callback
}: StructureEditorProps) {
  if (!template) {
    return (
      <div className="h-full flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <p className="text-slate-500 text-sm">Select a template to edit structure</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col bg-slate-50">
      {/* Header */}
      <div className="p-4 bg-white border-b border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm">
            <span className="font-semibold text-slate-900">{template.name}</span>
            <span className="text-slate-400">/</span>
            <span className="text-slate-600">Structure</span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="ghost" className="h-7 px-2" onClick={onAddSection}>
              <Plus className="h-4 w-4 mr-1" />
              New
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={onExpandAll}>
              <Maximize2 className="h-3.5 w-3.5 mr-1.5" />
              Expand All
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={onCollapseAll}>
              <Minimize2 className="h-3.5 w-3.5 mr-1.5" />
              Collapse All
            </Button>
          </div>
        </div>
      </div>

      {/* Tree Content */}
      <ScrollArea className="flex-1">
        <div className="p-4">
          <TreeView
            nodes={treeData}
            selectedNode={selectedNode}
            onSelectNode={onSelectNode}
            onEditSection={onEditSection}
            onAddChildSection={onAddChildSection}
            onMoveUp={onMoveUp}
            onMoveDown={onMoveDown}
            onDeleteSection={onDeleteSection}
            onIndent={onIndent}
            onOutdent={onOutdent}
            expandedIds={expandedIds}
            onToggleExpand={onToggleExpand}
          />
        </div>
      </ScrollArea>
    </div>
  )
}
