"use client"

import { useState } from "react"
import {
  GripVertical,
  ChevronDown,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  CornerDownRight,
  CornerUpLeft,
  Plus,
  Trash2,
  Pencil,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { TreeNode } from "@/app/page"

interface TreeViewProps {
  nodes: TreeNode[]
  selectedNode: TreeNode | null
  onSelectNode: (node: TreeNode) => void
  onEditSection: (node: TreeNode) => void
  onAddChildSection: (parentNode: TreeNode) => void
  onMoveUp: (node: TreeNode) => void
  onMoveDown: (node: TreeNode) => void
  onDeleteSection: (node: TreeNode) => void
  onIndent: (node: TreeNode) => void // Added indent callback
  onOutdent: (node: TreeNode) => void // Added outdent callback
  depth?: number
  parentNode?: TreeNode | null // Added parentNode to track parent
  expandedIds?: Set<string> // Made expandedIds controllable from outside
  onToggleExpand?: (id: string) => void // Added callback for expand/collapse
}

export function TreeView({
  nodes,
  selectedNode,
  onSelectNode,
  onEditSection,
  onAddChildSection,
  onMoveUp,
  onMoveDown,
  onDeleteSection,
  onIndent, // Added indent callback
  onOutdent, // Added outdent callback
  depth = 0,
  parentNode = null, // Added parentNode
  expandedIds: controlledExpandedIds, // Accept controlled expandedIds
  onToggleExpand, // Accept toggle callback
}: TreeViewProps) {
  const [localExpandedIds, setLocalExpandedIds] = useState<Set<string>>(new Set(["1", "3"]))

  // Use controlled or local state
  const expandedIds = controlledExpandedIds || localExpandedIds

  const toggleExpand = (id: string) => {
    if (onToggleExpand) {
      onToggleExpand(id)
    } else {
      const newExpanded = new Set(localExpandedIds)
      if (newExpanded.has(id)) {
        newExpanded.delete(id)
      } else {
        newExpanded.add(id)
      }
      setLocalExpandedIds(newExpanded)
    }
  }

  return (
    <div className="space-y-0.5">
      {nodes.map((node, index) => {
        const isExpanded = expandedIds.has(node.id)
        const hasChildren = node.children.length > 0
        const isSelected = selectedNode?.id === node.id
        const canMoveUp = index > 0
        const canMoveDown = index < nodes.length - 1
        const canIndent = index > 0 // Can indent if there's a previous sibling
        const canOutdent = depth > 0 // Can outdent if not at root level

        return (
          <div key={node.id}>
            {/* Tree Item */}
            <div
              className={`group flex items-center gap-2 py-2 px-2 rounded-md cursor-pointer transition-all ${
                isSelected ? "bg-blue-50 border border-blue-200" : "hover:bg-slate-100"
              }`}
              style={{ paddingLeft: `${depth * 24 + 8}px` }}
              onClick={() => onSelectNode(node)}
            >
              {/* Expand/Collapse */}
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  if (hasChildren) toggleExpand(node.id)
                }}
                className="flex-shrink-0"
              >
                {hasChildren ? (
                  isExpanded ? (
                    <ChevronDown className="h-4 w-4 text-slate-500" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-slate-500" />
                  )
                ) : (
                  <div className="w-4" />
                )}
              </button>

              <GripVertical className="h-4 w-4 text-slate-400 flex-shrink-0" />

              {/* Section Number */}
              <Badge variant="outline" className="h-5 px-1.5 font-mono text-xs border-slate-300 flex-shrink-0">
                {node.number}
              </Badge>

              {/* Section Title */}
              <div className="flex-1 text-sm text-slate-900 font-medium min-w-0">{node.title}</div>

              {/* Hover Actions */}
              <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0"
                  disabled={!canMoveUp}
                  onClick={(e) => {
                    e.stopPropagation()
                    if (canMoveUp) onMoveUp(node)
                  }}
                >
                  <ArrowUp className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0"
                  disabled={!canMoveDown}
                  onClick={(e) => {
                    e.stopPropagation()
                    if (canMoveDown) onMoveDown(node)
                  }}
                >
                  <ArrowDown className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0"
                  disabled={!canIndent}
                  onClick={(e) => {
                    e.stopPropagation()
                    if (canIndent) onIndent(node)
                  }}
                >
                  <CornerDownRight className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0"
                  disabled={!canOutdent}
                  onClick={(e) => {
                    e.stopPropagation()
                    if (canOutdent) onOutdent(node)
                  }}
                >
                  <CornerUpLeft className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation()
                    onAddChildSection(node)
                  }}
                >
                  <Plus className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation()
                    onEditSection(node)
                  }}
                >
                  <Pencil className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                  onClick={(e) => {
                    e.stopPropagation()
                    onDeleteSection(node)
                  }}
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>

            {/* Children */}
            {hasChildren && isExpanded && (
              <TreeView
                nodes={node.children}
                selectedNode={selectedNode}
                onSelectNode={onSelectNode}
                onEditSection={onEditSection}
                onAddChildSection={onAddChildSection}
                onMoveUp={onMoveUp}
                onMoveDown={onMoveDown}
                onDeleteSection={onDeleteSection}
                onIndent={onIndent} // Pass indent to children
                onOutdent={onOutdent} // Pass outdent to children
                depth={depth + 1}
                parentNode={node} // Pass current node as parent
                expandedIds={expandedIds} // Pass controlled state to children
                onToggleExpand={onToggleExpand} // Pass toggle callback to children
              />
            )}
          </div>
        )
      })}
    </div>
  )
}
