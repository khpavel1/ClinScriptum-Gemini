"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Check, ChevronsUpDown } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Mapping } from "@/app/page"

interface EditMappingDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  mapping: Mapping | null
  onSave: (mapping: Mapping) => void
}

const sourceTypes = [
  { value: "Protocol v1.0", label: "Protocol v1.0" },
  { value: "Protocol v2.0", label: "Protocol v2.0" },
  { value: "SAP v1.0", label: "Statistical Analysis Plan v1.0" },
  { value: "Database Lock", label: "Database Lock Report" },
  { value: "Safety Report", label: "Safety Monitoring Report" },
]

const sourceSections = [
  { value: "1.0 Introduction", label: "1.0 Introduction" },
  { value: "3.1 Primary Objectives", label: "3.1 Primary Objectives" },
  { value: "3.2 Secondary Objectives", label: "3.2 Secondary Objectives" },
  { value: "9.1 Overall Design", label: "9.1 Overall Design" },
  { value: "9.2 Study Duration", label: "9.2 Study Duration" },
  { value: "10.1 Inclusion Criteria", label: "10.1 Inclusion Criteria" },
  { value: "10.2 Exclusion Criteria", label: "10.2 Exclusion Criteria" },
]

export function EditMappingDialog({ open, onOpenChange, mapping, onSave }: EditMappingDialogProps) {
  const [sourceType, setSourceType] = useState("")
  const [sourceSection, setSourceSection] = useState("")
  const [instruction, setInstruction] = useState("")
  const [transformationType, setTransformationType] = useState<"direct" | "summarize" | "rephrase">("direct")
  const [openSourceType, setOpenSourceType] = useState(false)
  const [openSourceSection, setOpenSourceSection] = useState(false)

  useEffect(() => {
    if (mapping && open) {
      setSourceType(mapping.sourceType)
      setSourceSection(mapping.sourceSection)
      setInstruction(mapping.instruction)
      setTransformationType(mapping.transformationType)
    }
  }, [mapping, open])

  const handleSave = () => {
    if (mapping && sourceType && sourceSection && instruction) {
      onSave({
        ...mapping,
        sourceType,
        sourceSection,
        instruction,
        transformationType,
      })
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit Mapping Rule</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Source Type */}
          <div className="space-y-2">
            <Label>Source Document Type</Label>
            <Popover open={openSourceType} onOpenChange={setOpenSourceType}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={openSourceType}
                  className="w-full justify-between bg-transparent"
                >
                  {sourceType ? sourceTypes.find((type) => type.value === sourceType)?.label : "Select source type..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[560px] p-0">
                <Command>
                  <CommandInput placeholder="Search source types..." />
                  <CommandList>
                    <CommandEmpty>No source type found.</CommandEmpty>
                    <CommandGroup>
                      {sourceTypes.map((type) => (
                        <CommandItem
                          key={type.value}
                          value={type.value}
                          onSelect={(currentValue) => {
                            setSourceType(currentValue === sourceType ? "" : currentValue)
                            setOpenSourceType(false)
                          }}
                        >
                          <Check
                            className={cn("mr-2 h-4 w-4", sourceType === type.value ? "opacity-100" : "opacity-0")}
                          />
                          {type.label}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Source Section */}
          <div className="space-y-2">
            <Label>Source Section</Label>
            <Popover open={openSourceSection} onOpenChange={setOpenSourceSection}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={openSourceSection}
                  className="w-full justify-between bg-transparent"
                >
                  {sourceSection
                    ? sourceSections.find((section) => section.value === sourceSection)?.label
                    : "Select source section..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[560px] p-0">
                <Command>
                  <CommandInput placeholder="Search sections..." />
                  <CommandList>
                    <CommandEmpty>No section found.</CommandEmpty>
                    <CommandGroup>
                      {sourceSections.map((section) => (
                        <CommandItem
                          key={section.value}
                          value={section.value}
                          onSelect={(currentValue) => {
                            setSourceSection(currentValue === sourceSection ? "" : currentValue)
                            setOpenSourceSection(false)
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              sourceSection === section.value ? "opacity-100" : "opacity-0",
                            )}
                          />
                          {section.label}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Transformation Type */}
          <div className="space-y-2">
            <Label>Transformation Type</Label>
            <Select value={transformationType} onValueChange={(value: any) => setTransformationType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="direct">Direct Copy</SelectItem>
                <SelectItem value="summarize">Summarize</SelectItem>
                <SelectItem value="rephrase">Rephrase</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* AI Instruction */}
          <div className="space-y-2">
            <Label>AI Instruction</Label>
            <Textarea
              placeholder="e.g., Summarize in past tense, focusing on key outcomes..."
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              rows={4}
              className="resize-none"
            />
            <p className="text-xs text-slate-500">
              Provide specific instructions for how AI should transform the content
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!sourceType || !sourceSection || !instruction}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
