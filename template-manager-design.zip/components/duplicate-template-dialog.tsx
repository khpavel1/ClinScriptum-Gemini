"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Copy } from "lucide-react"
import type { Template } from "@/app/page"

interface DuplicateTemplateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  template: Template | null
  onSave: (name: string, version: string) => void
}

export function DuplicateTemplateDialog({ open, onOpenChange, template, onSave }: DuplicateTemplateDialogProps) {
  const [name, setName] = useState("")
  const [version, setVersion] = useState("")

  // Reset form when template changes or dialog opens
  const handleOpenChange = (isOpen: boolean) => {
    if (isOpen && template) {
      setName(`${template.name} (Copy)`)
      setVersion(template.version)
    }
    onOpenChange(isOpen)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (name.trim() && version.trim()) {
      onSave(name.trim(), version.trim())
      onOpenChange(false)
      setName("")
      setVersion("")
    }
  }

  if (!template) return null

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Copy className="h-5 w-5" />
            Duplicate Template
          </DialogTitle>
          <DialogDescription>
            Create a copy of <strong>{template.name}</strong>. All sections and mappings will be duplicated.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="duplicate-name">Template Name</Label>
              <Input
                id="duplicate-name"
                placeholder="Enter template name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duplicate-version">Version</Label>
              <Input
                id="duplicate-version"
                placeholder="e.g., v1.0"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Duplicate Template</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
