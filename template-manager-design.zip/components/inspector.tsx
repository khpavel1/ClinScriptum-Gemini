"use client"
import { Plus, Pencil, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card } from "@/components/ui/card"
import type { TreeNode, Mapping } from "@/app/page"

interface InspectorProps {
  selectedNode: TreeNode | null
  onUpdateNode: (node: TreeNode) => void
  onOpenMappingDialog: () => void
  onEditMapping: (mapping: Mapping) => void // Added edit mapping handler
  onDeleteMapping: (mapping: Mapping) => void // Added delete mapping handler
}

export function Inspector({
  selectedNode,
  onUpdateNode,
  onOpenMappingDialog,
  onEditMapping,
  onDeleteMapping,
}: InspectorProps) {
  if (!selectedNode) {
    return (
      <div className="h-full flex items-center justify-center bg-white border-l border-slate-200">
        <p className="text-sm text-slate-500">Select a section to view details</p>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col bg-white border-l border-slate-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-200">
        <h3 className="text-sm font-semibold text-slate-900 text-balance">
          Section Details: {selectedNode.number} {selectedNode.title}
        </h3>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="properties" className="flex-1 flex flex-col">
        <TabsList className="w-full rounded-none border-b border-slate-200 bg-transparent p-0">
          <TabsTrigger
            value="properties"
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent"
          >
            Properties
          </TabsTrigger>
          <TabsTrigger
            value="mappings"
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent"
          >
            Mappings
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1">
          {/* Properties Tab */}
          <TabsContent value="properties" className="p-4 space-y-4 mt-0">
            <div className="space-y-2">
              <Label htmlFor="title" className="text-xs font-medium text-slate-700">
                Title
              </Label>
              <Input
                id="title"
                value={selectedNode.title}
                className="h-9 text-sm"
                onChange={(e) => onUpdateNode({ ...selectedNode, title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-xs font-medium text-slate-700">
                Description / Context for AI
              </Label>
              <Textarea
                id="description"
                value={selectedNode.description}
                rows={4}
                className="text-sm resize-none"
                onChange={(e) => onUpdateNode({ ...selectedNode, description: e.target.value })}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="mandatory" className="text-xs font-medium text-slate-700">
                Is Mandatory?
              </Label>
              <Switch
                id="mandatory"
                checked={selectedNode.isMandatory}
                onCheckedChange={(checked) => onUpdateNode({ ...selectedNode, isMandatory: checked })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type" className="text-xs font-medium text-slate-700">
                Section Type
              </Label>
              <Select
                value={selectedNode.type}
                onValueChange={(value: "text" | "table" | "mixed") => onUpdateNode({ ...selectedNode, type: value })}
              >
                <SelectTrigger id="type" className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="table">Table</SelectItem>
                  <SelectItem value="mixed">Mixed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          {/* Mappings Tab */}
          <TabsContent value="mappings" className="p-4 space-y-4 mt-0">
            <p className="text-xs text-slate-600">Define where data comes from for this section.</p>

            {/* Mapping List */}
            <div className="space-y-2">
              {selectedNode.mappings.map((mapping) => (
                <Card key={mapping.id} className="p-3 border-slate-200">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-slate-900 mb-1">
                          Source: {mapping.sourceType} → {mapping.sourceSection}
                        </div>
                        <div className="text-xs text-slate-600 text-pretty">{mapping.instruction}</div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={() => onEditMapping(mapping)}
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                          onClick={() => onDeleteMapping(mapping)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}

              {selectedNode.mappings.length === 0 && (
                <div className="text-center py-8 text-sm text-slate-500">No mapping rules defined yet</div>
              )}
            </div>

            {/* Add Mapping Button */}
            <Button variant="outline" className="w-full bg-transparent" onClick={onOpenMappingDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add Mapping Rule
            </Button>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  )
}
