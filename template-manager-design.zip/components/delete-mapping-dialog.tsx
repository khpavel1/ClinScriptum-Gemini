"use client"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import type { Mapping } from "@/app/page"

interface DeleteMappingDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  mapping: Mapping | null
  onConfirm: () => void
}

export function DeleteMappingDialog({ open, onOpenChange, mapping, onConfirm }: DeleteMappingDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Mapping Rule</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete the mapping rule from <strong>{mapping?.sourceSection}</strong>? This action
            cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className="bg-destructive hover:bg-destructive/90">
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
