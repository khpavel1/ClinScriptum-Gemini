"use client"

import { Plus, Search, MoreVertical, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import type { Template } from "@/app/page"

interface TemplateLibraryProps {
  templates: Template[]
  selectedTemplate: Template | null
  onSelectTemplate: (template: Template) => void
  onAddTemplate: () => void
  onDuplicateTemplate: (template: Template) => void // Added duplicate handler
  onDeleteTemplate: (template: Template) => void // Added delete handler
  onArchiveTemplate: (template: Template) => void // Added archive handler
}

export function TemplateLibrary({
  templates,
  selectedTemplate,
  onSelectTemplate,
  onAddTemplate,
  onDuplicateTemplate,
  onDeleteTemplate,
  onArchiveTemplate, // Added archive handler
}: TemplateLibraryProps) {
  return (
    <div className="h-full flex flex-col bg-white border-r border-slate-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-900">Ideal Templates</h2>
          <Button size="sm" variant="ghost" className="h-7 px-2" onClick={onAddTemplate}>
            <Plus className="h-4 w-4 mr-1" />
            New
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <Input placeholder="Search templates..." className="pl-8 h-9 text-sm bg-slate-50 border-slate-200" />
        </div>
      </div>

      {/* Template List */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {templates.map((template) => (
            <div
              key={template.id}
              className={`group relative flex items-start gap-2 p-3 mb-1 rounded-md cursor-pointer transition-colors ${
                selectedTemplate?.id === template.id ? "bg-blue-50 text-blue-700" : "hover:bg-slate-100 text-slate-700"
              }`}
              onClick={() => onSelectTemplate(template)}
            >
              <ChevronRight className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium leading-tight mb-1 text-pretty">{template.name}</div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="h-5 px-1.5 text-xs font-mono border-slate-300">
                    {template.version}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <div
                      className={`w-1.5 h-1.5 rounded-full ${
                        template.status === "active"
                          ? "bg-green-500"
                          : template.status === "draft"
                            ? "bg-yellow-500"
                            : "bg-slate-400"
                      }`}
                    />
                    <span className="text-xs text-slate-500 capitalize">{template.status}</span>
                  </div>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <MoreVertical className="h-3.5 w-3.5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Edit Meta</DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation()
                      onDuplicateTemplate(template)
                    }}
                  >
                    Duplicate
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation()
                      onArchiveTemplate(template)
                    }}
                  >
                    Archive
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={(e) => {
                      e.stopPropagation()
                      onDeleteTemplate(template)
                    }}
                  >
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
