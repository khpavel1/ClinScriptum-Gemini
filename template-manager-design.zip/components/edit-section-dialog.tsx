"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import type { TreeNode } from "@/app/page"

interface EditSectionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  section: TreeNode | null
  onSave: (section: TreeNode) => void
}

export function EditSectionDialog({ open, onOpenChange, section, onSave }: EditSectionDialogProps) {
  const [number, setNumber] = useState("")
  const [title, setTitle] = useState("")
  const [type, setType] = useState<"text" | "table" | "mixed">("text")
  const [isMandatory, setIsMandatory] = useState(true)
  const [description, setDescription] = useState("")

  useEffect(() => {
    if (section) {
      setNumber(section.number)
      setTitle(section.title)
      setType(section.type)
      setIsMandatory(section.isMandatory)
      setDescription(section.description)
    }
  }, [section])

  const handleSave = () => {
    if (section && number.trim() && title.trim()) {
      onSave({
        ...section,
        number,
        title,
        type,
        isMandatory,
        description,
      })
      onOpenChange(false)
    }
  }

  if (!section) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Section</DialogTitle>
          <DialogDescription>Update the section properties</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="number">Section Number</Label>
            <Input id="number" value={number} onChange={(e) => setNumber(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="title">Section Title</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="type">Content Type</Label>
            <Select value={type} onValueChange={(value: any) => setType(value)}>
              <SelectTrigger id="type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="table">Table</SelectItem>
                <SelectItem value="mixed">Mixed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="mandatory" checked={isMandatory} onCheckedChange={(checked) => setIsMandatory(!!checked)} />
            <Label htmlFor="mandatory" className="text-sm font-normal cursor-pointer">
              This section is mandatory
            </Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!number.trim() || !title.trim()}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
