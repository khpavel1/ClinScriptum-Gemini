"use client"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import type { TreeNode } from "@/app/page"

interface DeleteSectionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  section: TreeNode | null
  onConfirm: () => void
}

export function DeleteSectionDialog({ open, onOpenChange, section, onConfirm }: DeleteSectionDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Section</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete section{" "}
            <strong>
              {section?.number} {section?.title}
            </strong>
            ?
            {section?.children && section.children.length > 0 && (
              <span className="block mt-2 text-destructive">
                This section has {section.children.length} child section(s) that will also be deleted.
              </span>
            )}
            This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className="bg-destructive hover:bg-destructive/90">
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
