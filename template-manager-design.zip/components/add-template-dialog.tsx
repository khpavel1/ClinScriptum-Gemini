"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Template } from "@/app/page"

interface AddTemplateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (template: Omit<Template, "id">) => void
}

export function AddTemplateDialog({ open, onOpenChange, onSave }: AddTemplateDialogProps) {
  const [name, setName] = useState("")
  const [version, setVersion] = useState("")
  const [status, setStatus] = useState<"active" | "draft" | "archived">("draft")

  const handleSave = () => {
    if (name.trim() && version.trim()) {
      onSave({ name, version, status })
      // Reset form
      setName("")
      setVersion("")
      setStatus("draft")
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Template</DialogTitle>
          <DialogDescription>Create a new ideal template for document generation</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Template Name</Label>
            <Input
              id="name"
              placeholder="e.g., ICH E3 - Clinical Study Report"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="version">Version</Label>
            <Input id="version" placeholder="e.g., v1.0" value={version} onChange={(e) => setVersion(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="status">Status</Label>
            <Select value={status} onValueChange={(value: any) => setStatus(value)}>
              <SelectTrigger id="status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!name.trim() || !version.trim()}>
            Create Template
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
