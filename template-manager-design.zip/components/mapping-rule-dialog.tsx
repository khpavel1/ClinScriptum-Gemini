"use client"

import { useState } from "react"
import { Check, ChevronsUpDown } from "lucide-react"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import type { Mapping } from "@/app/page"

interface MappingRuleDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (mapping: Mapping) => void
}

const sourceSections = [
  { value: "3", label: "3. Objectives (Protocol v1)" },
  { value: "3.1", label: "3.1 Primary Objectives (Protocol v1)" },
  { value: "3.2", label: "3.2 Secondary Objectives (Protocol v1)" },
  { value: "9.1", label: "9.1 Overall Design (Protocol v1)" },
  { value: "9.2", label: "9.2 Study Population (Protocol v1)" },
]

export function MappingRuleDialog({ open, onOpenChange, onSave }: MappingRuleDialogProps) {
  const [sourceType, setSourceType] = useState("Protocol v1.0")
  const [sourceSection, setSourceSection] = useState("")
  const [instruction, setInstruction] = useState("")
  const [transformationType, setTransformationType] = useState<"direct" | "summarize" | "rephrase">("summarize")
  const [sectionOpen, setSectionOpen] = useState(false)

  const handleSave = () => {
    const newMapping: Mapping = {
      id: Math.random().toString(36).substr(2, 9),
      sourceType,
      sourceSection: sourceSections.find((s) => s.value === sourceSection)?.label || sourceSection,
      instruction,
      transformationType,
    }
    onSave(newMapping)
    onOpenChange(false)
    // Reset form
    setSourceSection("")
    setInstruction("")
    setTransformationType("summarize")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Configure Data Source</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Step 1: Source Selection */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                Step 1: Source Selection
              </Label>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sourceType" className="text-sm">
                Source Template Type
              </Label>
              <Select value={sourceType} onValueChange={setSourceType}>
                <SelectTrigger id="sourceType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Protocol v1.0">Protocol v1.0</SelectItem>
                  <SelectItem value="SAP v1.0">SAP v1.0</SelectItem>
                  <SelectItem value="IB v2.0">Investigator Brochure v2.0</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm">Search Source Section</Label>
              <Popover open={sectionOpen} onOpenChange={setSectionOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={sectionOpen}
                    className="w-full justify-between font-normal bg-transparent"
                  >
                    {sourceSection
                      ? sourceSections.find((section) => section.value === sourceSection)?.label
                      : "Search for a section..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[550px] p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Type to search sections..." />
                    <CommandList>
                      <CommandEmpty>No section found.</CommandEmpty>
                      <CommandGroup>
                        {sourceSections.map((section) => (
                          <CommandItem
                            key={section.value}
                            value={section.value}
                            onSelect={(currentValue) => {
                              setSourceSection(currentValue === sourceSection ? "" : currentValue)
                              setSectionOpen(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                sourceSection === section.value ? "opacity-100" : "opacity-0",
                              )}
                            />
                            {section.label}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Step 2: Transformation */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                Step 2: Transformation
              </Label>
            </div>

            <div className="space-y-2">
              <Label htmlFor="instruction" className="text-sm">
                AI Instruction
              </Label>
              <Textarea
                id="instruction"
                placeholder="E.g., Extract key endpoints and present as a bullet list"
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                rows={3}
                className="resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="transformationType" className="text-sm">
                Transformation Type
              </Label>
              <Select
                value={transformationType}
                onValueChange={(value: "direct" | "summarize" | "rephrase") => setTransformationType(value)}
              >
                <SelectTrigger id="transformationType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="direct">Direct Copy</SelectItem>
                  <SelectItem value="summarize">Summarize</SelectItem>
                  <SelectItem value="rephrase">Rephrase</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Rule</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
