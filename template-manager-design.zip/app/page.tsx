"use client"

import { useState } from "react"
import { TemplateLibrary } from "@/components/template-library"
import { StructureEditor } from "@/components/structure-editor"
import { Inspector } from "@/components/inspector"
import { MappingRuleDialog } from "@/components/mapping-rule-dialog"
import { AddTemplateDialog } from "@/components/add-template-dialog"
import { AddSectionDialog } from "@/components/add-section-dialog"
import { EditSectionDialog } from "@/components/edit-section-dialog"
import { DeleteSectionDialog } from "@/components/delete-section-dialog"
import { EditMappingDialog } from "@/components/edit-mapping-dialog"
import { DeleteMappingDialog } from "@/components/delete-mapping-dialog"
import { DeleteTemplateDialog } from "@/components/delete-template-dialog"
import { DuplicateTemplateDialog } from "@/components/duplicate-template-dialog"
import { ArchiveTemplateDialog } from "@/components/archive-template-dialog"
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable"

export interface Template {
  id: string
  name: string
  version: string
  status: "active" | "draft" | "archived"
}

export interface TreeNode {
  id: string
  number: string
  title: string
  type: "text" | "table" | "mixed"
  isMandatory: boolean
  description: string
  children: TreeNode[]
  mappings: Mapping[]
}

export interface Mapping {
  id: string
  sourceType: string
  sourceSection: string
  instruction: string
  transformationType: "direct" | "summarize" | "rephrase"
}

const mockTemplates: Template[] = [
  { id: "1", name: "ICH E3 - Clinical Study Report", version: "v2.0", status: "active" },
  { id: "2", name: "ICH E6 - Good Clinical Practice", version: "v1.5", status: "active" },
  { id: "3", name: "Clinical Protocol Template", version: "v3.1", status: "active" },
  { id: "4", name: "Statistical Analysis Plan", version: "v2.2", status: "draft" },
]

const mockTreeData: TreeNode[] = [
  {
    id: "1",
    number: "1",
    title: "Introduction",
    type: "text",
    isMandatory: true,
    description: "Provide overview of the study",
    mappings: [],
    children: [
      {
        id: "1.1",
        number: "1.1",
        title: "Background",
        type: "text",
        isMandatory: true,
        description: "Context and rationale",
        mappings: [],
        children: [],
      },
    ],
  },
  {
    id: "3",
    number: "3",
    title: "Study Design",
    type: "mixed",
    isMandatory: true,
    description: "Complete study design details",
    mappings: [
      {
        id: "m1",
        sourceType: "Protocol v1.0",
        sourceSection: "9.1 Overall Design",
        instruction: "Summarize in past tense",
        transformationType: "summarize",
      },
    ],
    children: [
      {
        id: "3.1",
        number: "3.1",
        title: "Study Objectives",
        type: "text",
        isMandatory: true,
        description: "Primary and secondary objectives",
        mappings: [
          {
            id: "m2",
            sourceType: "Protocol v1.0",
            sourceSection: "3.1 Primary Objectives",
            instruction: "Extract key endpoints and present as a bullet list",
            transformationType: "rephrase",
          },
        ],
        children: [],
      },
      {
        id: "3.2",
        number: "3.2",
        title: "Study Population",
        type: "table",
        isMandatory: true,
        description: "Demographics and enrollment criteria",
        mappings: [],
        children: [],
      },
    ],
  },
  {
    id: "4",
    number: "4",
    title: "Results",
    type: "mixed",
    isMandatory: true,
    description: "Study results and findings",
    mappings: [],
    children: [],
  },
]

export default function TemplateManagerPage() {
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(mockTemplates[0])
  const [treeData, setTreeData] = useState<TreeNode[]>(mockTreeData)
  const [selectedNode, setSelectedNode] = useState<TreeNode | null>(mockTreeData[1])
  const [isMappingDialogOpen, setIsMappingDialogOpen] = useState(false)

  const [isAddTemplateDialogOpen, setIsAddTemplateDialogOpen] = useState(false)
  const [isAddSectionDialogOpen, setIsAddSectionDialogOpen] = useState(false)
  const [isEditSectionDialogOpen, setIsEditSectionDialogOpen] = useState(false)
  const [templates, setTemplates] = useState<Template[]>(mockTemplates)
  const [sectionToEdit, setSectionToEdit] = useState<TreeNode | null>(null)
  const [parentNodeForNewSection, setParentNodeForNewSection] = useState<TreeNode | null>(null)

  const [isDeleteSectionDialogOpen, setIsDeleteSectionDialogOpen] = useState(false)
  const [sectionToDelete, setSectionToDelete] = useState<TreeNode | null>(null)

  const [isEditMappingDialogOpen, setIsEditMappingDialogOpen] = useState(false)
  const [isDeleteMappingDialogOpen, setIsDeleteMappingDialogOpen] = useState(false)
  const [mappingToEdit, setMappingToEdit] = useState<Mapping | null>(null)
  const [mappingToDelete, setMappingToDelete] = useState<Mapping | null>(null)

  const [isDeleteTemplateDialogOpen, setIsDeleteTemplateDialogOpen] = useState(false)
  const [templateToDelete, setTemplateToDelete] = useState<Template | null>(null)
  const [isDuplicateTemplateDialogOpen, setIsDuplicateTemplateDialogOpen] = useState(false)
  const [templateToDuplicate, setTemplateToDuplicate] = useState<Template | null>(null)

  const [isArchiveTemplateDialogOpen, setIsArchiveTemplateDialogOpen] = useState(false)
  const [templateToArchive, setTemplateToArchive] = useState<Template | null>(null)

  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(["1", "3"]))

  const handleMoveUp = (node: TreeNode) => {
    const moveUpInTree = (nodes: TreeNode[], parentPath: TreeNode[] = []): TreeNode[] => {
      const index = nodes.findIndex((n) => n.id === node.id)
      if (index > 0) {
        const newNodes = [...nodes]
        ;[newNodes[index - 1], newNodes[index]] = [newNodes[index], newNodes[index - 1]]
        return newNodes
      }

      return nodes.map((n) => ({
        ...n,
        children: n.children.length > 0 ? moveUpInTree(n.children, [...parentPath, n]) : n.children,
      }))
    }

    setTreeData(moveUpInTree(treeData))
  }

  const handleMoveDown = (node: TreeNode) => {
    const moveDownInTree = (nodes: TreeNode[], parentPath: TreeNode[] = []): TreeNode[] => {
      const index = nodes.findIndex((n) => n.id === node.id)
      if (index >= 0 && index < nodes.length - 1) {
        const newNodes = [...nodes]
        ;[newNodes[index], newNodes[index + 1]] = [newNodes[index + 1], newNodes[index]]
        return newNodes
      }

      return nodes.map((n) => ({
        ...n,
        children: n.children.length > 0 ? moveDownInTree(n.children, [...parentPath, n]) : n.children,
      }))
    }

    setTreeData(moveDownInTree(treeData))
  }

  const handleDeleteSection = (node: TreeNode) => {
    setSectionToDelete(node)
    setIsDeleteSectionDialogOpen(true)
  }

  const confirmDeleteSection = () => {
    if (!sectionToDelete) return

    const deleteFromTree = (nodes: TreeNode[]): TreeNode[] => {
      return nodes
        .filter((n) => n.id !== sectionToDelete.id)
        .map((n) => ({
          ...n,
          children: n.children.length > 0 ? deleteFromTree(n.children) : n.children,
        }))
    }

    setTreeData(deleteFromTree(treeData))

    // Clear selection if deleted node was selected
    if (selectedNode?.id === sectionToDelete.id) {
      setSelectedNode(null)
    }

    setIsDeleteSectionDialogOpen(false)
    setSectionToDelete(null)
  }

  const handleEditMapping = (mapping: Mapping) => {
    setMappingToEdit(mapping)
    setIsEditMappingDialogOpen(true)
  }

  const saveEditedMapping = (updatedMapping: Mapping) => {
    if (!selectedNode) return

    const updatedMappings = selectedNode.mappings.map((m) => (m.id === updatedMapping.id ? updatedMapping : m))

    const updatedNode = {
      ...selectedNode,
      mappings: updatedMappings,
    }

    setSelectedNode(updatedNode)

    // Update in tree
    const updateTree = (nodes: TreeNode[]): TreeNode[] => {
      return nodes.map((node) => {
        if (node.id === updatedNode.id) {
          return updatedNode
        }
        if (node.children.length > 0) {
          return { ...node, children: updateTree(node.children) }
        }
        return node
      })
    }
    setTreeData(updateTree(treeData))
  }

  const handleDeleteMapping = (mapping: Mapping) => {
    setMappingToDelete(mapping)
    setIsDeleteMappingDialogOpen(true)
  }

  const confirmDeleteMapping = () => {
    if (!selectedNode || !mappingToDelete) return

    const updatedMappings = selectedNode.mappings.filter((m) => m.id !== mappingToDelete.id)

    const updatedNode = {
      ...selectedNode,
      mappings: updatedMappings,
    }

    setSelectedNode(updatedNode)

    // Update in tree
    const updateTree = (nodes: TreeNode[]): TreeNode[] => {
      return nodes.map((node) => {
        if (node.id === updatedNode.id) {
          return updatedNode
        }
        if (node.children.length > 0) {
          return { ...node, children: updateTree(node.children) }
        }
        return node
      })
    }
    setTreeData(updateTree(treeData))

    setIsDeleteMappingDialogOpen(false)
    setMappingToDelete(null)
  }

  const handleIndent = (node: TreeNode) => {
    const indentInTree = (nodes: TreeNode[], parentPath: TreeNode[] = []): TreeNode[] => {
      const index = nodes.findIndex((n) => n.id === node.id)
      if (index > 0) {
        const newNodes = [...nodes]
        const previousSibling = newNodes[index - 1]
        const nodeToMove = newNodes.splice(index, 1)[0]
        previousSibling.children = [...previousSibling.children, nodeToMove]
        return newNodes
      }

      return nodes.map((n) => ({
        ...n,
        children: n.children.length > 0 ? indentInTree(n.children, [...parentPath, n]) : n.children,
      }))
    }

    setTreeData(indentInTree(treeData))
  }

  const handleOutdent = (node: TreeNode) => {
    const outdentInTree = (nodes: TreeNode[], parent: TreeNode | null = null): TreeNode[] => {
      for (let i = 0; i < nodes.length; i++) {
        const currentNode = nodes[i]
        const childIndex = currentNode.children.findIndex((n) => n.id === node.id)

        if (childIndex !== -1) {
          // Found the node in children, move it up
          const nodeToMove = currentNode.children[childIndex]
          const newChildren = [...currentNode.children]
          newChildren.splice(childIndex, 1)

          const newNodes = [...nodes]
          newNodes[i] = { ...currentNode, children: newChildren }
          newNodes.splice(i + 1, 0, nodeToMove)
          return newNodes
        }

        if (currentNode.children.length > 0) {
          const updatedChildren = outdentInTree(currentNode.children, currentNode)
          if (updatedChildren !== currentNode.children) {
            const newNodes = [...nodes]
            newNodes[i] = { ...currentNode, children: updatedChildren }
            return newNodes
          }
        }
      }
      return nodes
    }

    setTreeData(outdentInTree(treeData))
  }

  const handleExpandAll = () => {
    const collectAllIds = (nodes: TreeNode[]): string[] => {
      return nodes.flatMap((node) => [node.id, ...collectAllIds(node.children)])
    }
    setExpandedIds(new Set(collectAllIds(treeData)))
  }

  const handleCollapseAll = () => {
    setExpandedIds(new Set())
  }

  const handleToggleExpand = (id: string) => {
    const newExpanded = new Set(expandedIds)
    if (newExpanded.has(id)) {
      newExpanded.delete(id)
    } else {
      newExpanded.add(id)
    }
    setExpandedIds(newExpanded)
  }

  const handleDeleteTemplate = (template: Template) => {
    setTemplateToDelete(template)
    setIsDeleteTemplateDialogOpen(true)
  }

  const confirmDeleteTemplate = () => {
    if (!templateToDelete) return
    const updatedTemplates = templates.filter((t) => t.id !== templateToDelete.id)
    setTemplates(updatedTemplates)
    if (selectedTemplate?.id === templateToDelete.id) {
      setSelectedTemplate(updatedTemplates.length > 0 ? updatedTemplates[0] : null)
    }
    setIsDeleteTemplateDialogOpen(false)
    setTemplateToDelete(null)
  }

  const handleDuplicateTemplate = (template: Template) => {
    setTemplateToDuplicate(template)
    setIsDuplicateTemplateDialogOpen(true)
  }

  const confirmDuplicateTemplate = (name: string, version: string) => {
    if (!templateToDuplicate) return
    const newTemplate: Template = {
      id: String(Date.now()),
      name,
      version,
      status: "draft",
    }
    setTemplates([...templates, newTemplate])
    setIsDuplicateTemplateDialogOpen(false)
    setTemplateToDuplicate(null)
  }

  const handleArchiveTemplate = (template: Template) => {
    setTemplateToArchive(template)
    setIsArchiveTemplateDialogOpen(true)
  }

  const confirmArchiveTemplate = () => {
    if (!templateToArchive) return
    const updatedTemplates = templates.map((t) =>
      t.id === templateToArchive.id ? { ...t, status: "archived" as const } : t,
    )
    setTemplates(updatedTemplates)
    setIsArchiveTemplateDialogOpen(false)
    setTemplateToArchive(null)
  }

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      <ResizablePanelGroup direction="horizontal" className="flex-1">
        {/* Panel 1: Template Library */}
        <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
          <TemplateLibrary
            templates={templates}
            selectedTemplate={selectedTemplate}
            onSelectTemplate={setSelectedTemplate}
            onAddTemplate={() => setIsAddTemplateDialogOpen(true)}
            onDuplicateTemplate={handleDuplicateTemplate}
            onDeleteTemplate={handleDeleteTemplate}
            onArchiveTemplate={handleArchiveTemplate}
          />
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Panel 2: Structure Editor */}
        <ResizablePanel defaultSize={50} minSize={30}>
          <StructureEditor
            template={selectedTemplate}
            treeData={treeData}
            selectedNode={selectedNode}
            onSelectNode={setSelectedNode}
            onAddSection={() => {
              setParentNodeForNewSection(null)
              setIsAddSectionDialogOpen(true)
            }}
            onEditSection={(node) => {
              setSectionToEdit(node)
              setIsEditSectionDialogOpen(true)
            }}
            onAddChildSection={(parentNode) => {
              setParentNodeForNewSection(parentNode)
              setIsAddSectionDialogOpen(true)
            }}
            onMoveUp={handleMoveUp}
            onMoveDown={handleMoveDown}
            onDeleteSection={handleDeleteSection}
            onIndent={handleIndent}
            onOutdent={handleOutdent}
            onExpandAll={handleExpandAll}
            onCollapseAll={handleCollapseAll}
            expandedIds={expandedIds}
            onToggleExpand={handleToggleExpand}
          />
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Panel 3: Inspector */}
        <ResizablePanel defaultSize={30} minSize={25}>
          <Inspector
            selectedNode={selectedNode}
            onUpdateNode={(updatedNode) => {
              setSelectedNode(updatedNode)
            }}
            onOpenMappingDialog={() => setIsMappingDialogOpen(true)}
            onEditMapping={handleEditMapping}
            onDeleteMapping={handleDeleteMapping}
          />
        </ResizablePanel>
      </ResizablePanelGroup>

      {/* Mapping Rule Dialog */}
      <MappingRuleDialog
        open={isMappingDialogOpen}
        onOpenChange={setIsMappingDialogOpen}
        onSave={(mapping) => {
          if (selectedNode) {
            const updatedNode = {
              ...selectedNode,
              mappings: [...selectedNode.mappings, mapping],
            }
            setSelectedNode(updatedNode)
          }
        }}
      />

      <AddTemplateDialog
        open={isAddTemplateDialogOpen}
        onOpenChange={setIsAddTemplateDialogOpen}
        onSave={(template) => {
          const newTemplate = { ...template, id: String(templates.length + 1) }
          setTemplates([...templates, newTemplate])
        }}
      />

      <AddSectionDialog
        open={isAddSectionDialogOpen}
        onOpenChange={setIsAddSectionDialogOpen}
        onSave={(section) => {
          const newSection = { ...section, id: String(Date.now()), mappings: [] }

          if (parentNodeForNewSection) {
            // Add as child to parent node
            const addChildToTree = (nodes: TreeNode[]): TreeNode[] => {
              return nodes.map((node) => {
                if (node.id === parentNodeForNewSection.id) {
                  return { ...node, children: [...node.children, newSection] }
                }
                if (node.children.length > 0) {
                  return { ...node, children: addChildToTree(node.children) }
                }
                return node
              })
            }
            setTreeData(addChildToTree(treeData))
          } else {
            // Add as root section
            setTreeData([...treeData, newSection])
          }

          setParentNodeForNewSection(null)
        }}
      />

      <EditSectionDialog
        open={isEditSectionDialogOpen}
        onOpenChange={setIsEditSectionDialogOpen}
        section={sectionToEdit}
        onSave={(updatedSection) => {
          // Update the section in the tree
          const updateTree = (nodes: TreeNode[]): TreeNode[] => {
            return nodes.map((node) => {
              if (node.id === updatedSection.id) {
                return updatedSection
              }
              if (node.children.length > 0) {
                return { ...node, children: updateTree(node.children) }
              }
              return node
            })
          }
          setTreeData(updateTree(treeData))
          if (selectedNode?.id === updatedSection.id) {
            setSelectedNode(updatedSection)
          }
        }}
      />

      <DeleteSectionDialog
        open={isDeleteSectionDialogOpen}
        onOpenChange={setIsDeleteSectionDialogOpen}
        section={sectionToDelete}
        onConfirm={confirmDeleteSection}
      />

      <EditMappingDialog
        open={isEditMappingDialogOpen}
        onOpenChange={setIsEditMappingDialogOpen}
        mapping={mappingToEdit}
        onSave={saveEditedMapping}
      />

      <DeleteMappingDialog
        open={isDeleteMappingDialogOpen}
        onOpenChange={setIsDeleteMappingDialogOpen}
        mapping={mappingToDelete}
        onConfirm={confirmDeleteMapping}
      />

      {/* Delete Template Dialog */}
      <DeleteTemplateDialog
        open={isDeleteTemplateDialogOpen}
        onOpenChange={setIsDeleteTemplateDialogOpen}
        template={templateToDelete}
        onConfirm={confirmDeleteTemplate}
      />

      {/* Duplicate Template Dialog */}
      <DuplicateTemplateDialog
        open={isDuplicateTemplateDialogOpen}
        onOpenChange={setIsDuplicateTemplateDialogOpen}
        template={templateToDuplicate}
        onSave={confirmDuplicateTemplate}
      />

      <ArchiveTemplateDialog
        open={isArchiveTemplateDialogOpen}
        onOpenChange={setIsArchiveTemplateDialogOpen}
        template={templateToArchive}
        onConfirm={confirmArchiveTemplate}
      />
    </div>
  )
}
